﻿namespace $safeprojectname$
{
    public class ItemDetailViewModel : BaseViewModel
    {
        public ItemDetailViewModel()
        {
        }
    }
}
