﻿namespace $safeprojectname$
{
    public class HomeMasterViewModel : BaseViewModel
    {
    }
}
