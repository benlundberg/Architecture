﻿using $safeprojectname$.Core;
using Xamarin.Essentials;

namespace $safeprojectname$
{
    public class ConnectivityService : IConnectivityService
    {
        public bool IsConnected => Connectivity.NetworkAccess != NetworkAccess.None;
    }
}
