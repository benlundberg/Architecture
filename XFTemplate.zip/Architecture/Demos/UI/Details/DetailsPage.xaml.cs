﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Demos.UI.Details
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class DetailsPage : ContentPage
	{
		public DetailsPage()
		{
			InitializeComponent();
		}
	}
}
