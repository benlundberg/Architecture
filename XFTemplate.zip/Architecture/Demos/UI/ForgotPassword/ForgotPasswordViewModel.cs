﻿using System;
namespace $safeprojectname$.Demos.UI.ForgotPassword
{
	public class ForgotPasswordViewModel : BaseViewModel
	{
		public ForgotPasswordViewModel()
		{
		}
	}
}
