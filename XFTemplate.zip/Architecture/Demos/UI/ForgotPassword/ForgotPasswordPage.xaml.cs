﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Demos
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ForgotPasswordPage : Controls.ExtendedContentPage
	{
		public ForgotPasswordPage()
		{
			InitializeComponent();
		}
	}
}
