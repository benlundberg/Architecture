﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Demos.UI.List
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ListPage : ContentPage
	{
		public ListPage()
		{
			InitializeComponent();
		}
	}
}
