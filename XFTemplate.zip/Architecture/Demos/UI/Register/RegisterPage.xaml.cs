﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Demos.UI.Register
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class RegisterPage : ContentPage
	{
		public RegisterPage()
		{
			InitializeComponent();
		}
	}
}
