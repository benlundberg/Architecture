﻿using System;
namespace $safeprojectname$.Demos.UI.Register
{
	public class RegisterViewModel : BaseViewModel
	{
		public RegisterViewModel()
		{
		}
	}
}
