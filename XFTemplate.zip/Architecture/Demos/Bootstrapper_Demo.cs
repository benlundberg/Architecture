﻿using $safeprojectname$.Demos.UI.GridView;
using $safeprojectname$.Demos.UI.Login;
using $safeprojectname$.Demos.UI.ForgotPassword;
using $safeprojectname$.Demos.UI.List;
using $safeprojectname$.Demos.UI.Register;
using $safeprojectname$.Demos.UI.Details;

namespace $safeprojectname$.Demos
{
    public class Bootstrapper_Demo
    {
        public static void Init()
        {
            ViewContainer.Current.Register<LoginViewModel, LoginPage>();
			ViewContainer.Current.Register<ListViewModel, ListPage>();
			ViewContainer.Current.Register<GridViewModel, GridPage>();
			ViewContainer.Current.Register<ForgotPasswordViewModel, ForgotPasswordPage>();
			ViewContainer.Current.Register<RegisterViewModel, RegisterPage>();
			ViewContainer.Current.Register<DetailsViewModel, DetailsPage>();
		}
	}
}
