﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskBrowserPage : ContentPage
    {
        public TaskBrowserPage()
        {
            InitializeComponent();
        }
    }
}