﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.UIKit.Views.Phone
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskOverviewPage : ContentPage
    {
        public TaskOverviewPage()
        {
            InitializeComponent();
        }
    }
}