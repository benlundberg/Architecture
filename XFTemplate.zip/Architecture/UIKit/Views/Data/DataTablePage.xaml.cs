﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DataTablePage : ContentPage
    {
        public DataTablePage()
        {
            InitializeComponent();
        }
    }
}