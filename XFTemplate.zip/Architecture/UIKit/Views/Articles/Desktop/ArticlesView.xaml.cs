﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.UIKit.Views.Desktop
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ArticlesView : ContentPage
    {
        public ArticlesView()
        {
            InitializeComponent();
        }
    }
}