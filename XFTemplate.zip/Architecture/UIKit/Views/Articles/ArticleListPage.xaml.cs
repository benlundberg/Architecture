﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ArticleListPage : ContentPage
    {
        public ArticleListPage()
        {
            InitializeComponent();
        }
    }
}