﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SearchPage : ContentPage
    {
        public SearchPage()
        {
            InitializeComponent();
        }
    }
}