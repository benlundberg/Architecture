﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.UIKit.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DashboardCardPage : ContentPage
    {
        public DashboardCardPage()
        {
            InitializeComponent();
        }
    }
}