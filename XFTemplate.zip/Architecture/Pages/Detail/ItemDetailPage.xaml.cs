﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ItemDetailPage : ContentPage
	{
		public ItemDetailPage ()
		{
			InitializeComponent ();
		}
	}
}