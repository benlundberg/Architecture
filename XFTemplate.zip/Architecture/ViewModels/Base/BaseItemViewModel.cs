﻿using System.ComponentModel;

namespace $safeprojectname$
{
    public class BaseItemViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
