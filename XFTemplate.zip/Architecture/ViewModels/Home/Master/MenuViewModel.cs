﻿using System;
using Xamarin.Forms;

namespace $safeprojectname$
{
    public class MenuViewModel
    {
        public MenuViewModel()
        {
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public Page Page { get; set; }
        public Action Action { get; set; }
    }
}