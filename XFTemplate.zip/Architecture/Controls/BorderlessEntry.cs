﻿using Xamarin.Forms;

namespace $safeprojectname$.Controls
{
    public class BorderlessEntry : Entry
    {
        public BorderlessEntry()
        {

        }
    }
}
