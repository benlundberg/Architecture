﻿using Xamarin.Forms;

namespace $safeprojectname$.Controls
{
    public enum GradientDirection
    {
        ToRight,
        ToLeft,
        ToTop,
        ToBottom,
        ToTopLeft,
        ToTopRight,
        ToBottomLeft,
        ToBottomRight
    }

    public class GradientView : StackLayout
    {
        public Color StartColor { get; set; } = Application.Current.PrimaryColor();
        public Color EndColor { get; set; } = Application.Current.DarkPrimaryColor();
        public GradientDirection Direction { get; set; }
    }
}
