﻿using System;

namespace $safeprojectname$
{
    public static class DateTimeExtensions
    {
        public static string GetMonthName(this DateTime dateTime)
        {

            return string.Empty;
            //var translateService = ComponentContainer.Current.Resolve<ITranslateService>();

            //switch (dateTime.Month)
            //{
            //    case 1:
            //        return translateService.Translate("Date_January");
            //    case 2:
            //        return translateService.Translate("Date_February");
            //    case 3:
            //        return translateService.Translate("Date_March");
            //    case 4:
            //        return translateService.Translate("Date_April");
            //    case 5:
            //        return translateService.Translate("Date_May");
            //    case 6:
            //        return translateService.Translate("Date_June");
            //    case 7:
            //        return translateService.Translate("Date_July");
            //    case 8:
            //        return translateService.Translate("Date_August");
            //    case 9:
            //        return translateService.Translate("Date_September");
            //    case 10:
            //        return translateService.Translate("Date_October");
            //    case 11:
            //        return translateService.Translate("Date_November");
            //    case 12:
            //        return translateService.Translate("Date_December");
            //    default:
            //        return translateService.Translate("Date_January");
            //}
        }
    }
}
