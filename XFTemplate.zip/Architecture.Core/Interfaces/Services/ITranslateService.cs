﻿namespace $safeprojectname$
{
    public interface ITranslateService
    {
        string Translate(string key);
    }
}
