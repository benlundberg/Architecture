﻿namespace $safeprojectname$
{
    public interface IConnectivityService
    {
        bool IsConnected { get; }
    }
}
