﻿namespace $safeprojectname$
{
    public interface IOpenFileService
    {
        void Open(string title, params string[] paths);
    }
}
