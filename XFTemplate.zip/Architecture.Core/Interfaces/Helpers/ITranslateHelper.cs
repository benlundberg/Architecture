﻿namespace $safeprojectname$
{
    public interface ITranslateHelper
    {
        string Translate(string key);
    }
}
