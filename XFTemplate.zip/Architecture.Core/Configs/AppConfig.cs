﻿namespace $safeprojectname$
{
    public class AppConfig
    {
        public const string AppName = "Architecture";
    }
}
