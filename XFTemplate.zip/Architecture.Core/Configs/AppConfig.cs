﻿namespace $safeprojectname$
{
    /// <summary>
    /// A class to keep the Apps configuration properties
    /// </summary>
    public class AppConfig
    {
        public const string AppName = "Architecture";
    }
}
