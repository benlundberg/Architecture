﻿namespace $safeprojectname$
{
    /// <summary>
    /// A class to keep all the API addresses
    /// </summary>
    public class ServiceConfig
    {
        public const string WEB_SERVICE_BASE_ADDRESS = "";
        public const string DOWNLOAD_FILE = "";
    }
}
