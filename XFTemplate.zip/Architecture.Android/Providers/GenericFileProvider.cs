﻿using Android.Support.V4.Content;

namespace $safeprojectname$
{
    public class GenericFileProvider : FileProvider { }
}